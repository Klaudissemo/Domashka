void clean_stdin(void);
float calculation (int k, float a, float b);